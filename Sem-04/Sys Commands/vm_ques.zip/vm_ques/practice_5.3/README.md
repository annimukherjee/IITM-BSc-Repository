# Week 5 Problem 3

Write a bash script named ` script.sh `. The script takes two arguments, checks if both the arguments are positive integers then prints their sum; else concatenate the string values in both the arguments and prints the combined string.
