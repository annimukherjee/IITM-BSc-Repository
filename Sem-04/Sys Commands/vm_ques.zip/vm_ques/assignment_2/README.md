# Assignment 2

Create a file named `<your_roll_number>.txt` in `~/se2001/assignment_2` and write a script `script.sh` in `~/se2001/assignment_2` to upload the file `<your_roll_number>.txt` to [http://local.server/upload/<your_roll_number>.txt](http://local.server/upload/<your_roll_number>.txt).

Hint: 
- Use can verify the uploaded the file kept temporarily in the location `/tmp/local_uploads`
- Use PUT request for while sending the file
