# Week 7 Problem 1

Write an awk script in ` file.awk ` that can list nth Fibonacci number where ` n ` is a command line argument to the script.
 
Note: The sequence is 1,1,2,3,5,..., and the first and the second value are 1 and 1.
