# Week 6 Problem 2

Write a bash script ` script.sh ` using sed to print the contents of file ` $filename ` in the format ` <line number>:<contents> `.
