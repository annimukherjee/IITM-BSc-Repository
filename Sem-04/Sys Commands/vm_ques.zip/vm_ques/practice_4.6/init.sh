dir="/opt/se2001/practice_4.6"
cp $dir/twocities.txt .
