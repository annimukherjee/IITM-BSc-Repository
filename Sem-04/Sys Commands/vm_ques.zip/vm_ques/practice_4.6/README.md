# Week 4 Problem 6

The command below gives the following output.

```bash 
$ cat twocities.txt
It was the best of times, it was the worst of times, 
it was the age of wisdom, it was the age of foolishness, 
it was the epoch of belief, it was the epoch of incredulity, 
it was the season of Light, it was the season of Darkness, 
it was the spring of hope, it was the winter of despair, 
we had everything before us, we had nothing before us, 
we were all going direct to Heaven, we were all going direct the other way
```

Write bash script ` script.sh ` using grep to find all the lines that end with the letter ` s ` (comma and space at end should be excluded), in the above file. Redirect your output to file ` out.txt `.

Note:
- Run ` synchro init ` to begin.
