# Assignment 4

**This assignment is only available between 7pm and 9pm IST**

Create an account in GitHub and create a public repository named `se2001-<roll_number>` (in lowercase) and initialize with README.md

Create a file named `script.sh` that exports two shell variables

- `GITHUB_USERNAME` that holds the GitHub username Ex: "bscse2001"
- `GITHUB_REPOSITORY` that holds the GitHub repository name Ex: "se2001-21f1000000"

The repository can be deleted after the evaluation and submission of Assignment 5 is successful.
