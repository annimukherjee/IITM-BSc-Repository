# Week 2 Problem 1

There is a file named ` final.txt ` in the current working directory, that contains some text that you do not want it to be edited. 

Write a bash command to remove write permissions of user from this file. Do not edit any other file permissions.

Note : Run ` synchro init ` to get the file ` final.txt ` to your solutions direcotry.
