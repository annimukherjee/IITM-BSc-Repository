touch final.txt
chmod 744 final.txt
echo "Final text" > final.txt
