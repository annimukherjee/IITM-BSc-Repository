# Week 2 Problem 10

The string ` colors ` contains the name of the colors.
Convert it to array of colors.

Your task is to write a bash script ` script.sh ` to remove all vowels present in the array and display them.

Example: ` colors="violet indigo blue green yellow orange red" `

Use the snippet below to convert a space separated string to an array.

```bash
arr=($str)
```

**Output**

```
vlt ndg bl grn yllw rng rd
```
