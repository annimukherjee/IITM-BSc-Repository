# Week 5 Problem 5c

Write a bash script that reads two numbers from the standard input and prints the sum of the numbers. Assume that the input will be numeric only.

Write your script in the file <code>script.sh</code>.
