# Week 7 Problem 5

The ` uniq ` command in the Linux will not print the adjacent duplicate lines. Write an AWK script ` script.awk ` to the same.
