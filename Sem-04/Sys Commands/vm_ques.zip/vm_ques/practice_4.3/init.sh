dir="/opt/se2001/practice_4.3"
cp $dir/twocities.txt .
