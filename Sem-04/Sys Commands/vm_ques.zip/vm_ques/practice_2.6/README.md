# Week 2 Problem 6

Write a bash script ` script.sh ` in directory ` ~/se2001/practice_2.6 ` to find the day of the week of April 1st of 2024 and print it to the output in full format with first letter capitalised. Ex: ` Wednesday `

Hint: Use ` date ` command.
