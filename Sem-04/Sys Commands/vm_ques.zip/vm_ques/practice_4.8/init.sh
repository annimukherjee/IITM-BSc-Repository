dir="/opt/se2001/practice_4.8"
cp $dir/file.txt .
