dir="/opt/se2001/practice_4.4"
cp $dir/twocities.txt .
