# Week 2 Problem 5

Write a bash script ` script.sh ` which prints the mime type of ` somefile ` located in ` ~/se2001/practice_2.5 `.

Hint: Use ` file `. Refer manual of ` file ` or ` file --help `.

Remember that:
- Initially you may not find any file. 
- The files are automatically created when you run ` synchro eval `.
- The same strategy is followed for most of the practice problems.
- You can create dummy files to check for yourself if your script works.
