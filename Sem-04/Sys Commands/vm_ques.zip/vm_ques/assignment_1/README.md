# Assignment 1

Write a script `script.sh` in `~/se2001/assignment_1` to download the file `sample_1.txt` from [http://local.server](http://local.server) and store it as `s1.txt` in `~/se2001/assignment_1/`

Hint: Use `wget` command

## Optional

If you are able to achieve the above task then,

- Try to download the file `sample_2.txt`, `sample_3.txt` and `sample_4.txt`.
- Use `cURL` to achieve the same.
