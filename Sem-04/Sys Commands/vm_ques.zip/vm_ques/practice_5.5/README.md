# Week 5 Problem 5

Write a bash script in ` script.sh ` file that takes an argument which takes a positive integer as argument and prints it in reverse order (For example, if the input number is 123, the Output will be 321)
