echo "Contents of File 1" > file1.txt
echo "Contents of File 2" > file2.txt
