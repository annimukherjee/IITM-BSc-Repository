dir="/opt/se2001/practice_4.9"
cp $dir/*.cp* .
