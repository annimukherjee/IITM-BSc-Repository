# Week 7 Problem 4

Write an AWK script in ` script.awk ` to count the number of lines in the file.
