# Week 7 Problem 2

Write an awk script ` file.awk ` to calculate class average marks of each subject and print each subject average in a new line. 

- The first line of output represents the class average of Mathematics.
- The second line of output represents the class average of Physics.
- The third line of output represents the class average of Chemistry.

The marks are given in the comma separated file ` marks.csv `.

Note:
- ` marks.csv ` will be available during evaluation.
