# Week 3 Problem 2

Write a bash script ` script.sh ` to redirect the stderr and stdout of the command ` ls file1.txt file2.txt ` in that particular order to ` output.txt `.
