# Week 2 Problem 9

Write a bash script ` script.sh ` to display only the filename without extension, whose absolute path is stored in a shell variable named ` file `. The extension should not include the dot ` . `.

Example: ` file=/home/student56/tmp/artic.jpg `

**Output**

```
artic
```
