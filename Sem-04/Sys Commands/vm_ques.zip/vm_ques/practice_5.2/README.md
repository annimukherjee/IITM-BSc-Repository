# Week 5 Problem 2

Write a bash script named ` script.sh ` that takes two arguments, checks if both the arguments are positive integers then prints their sum; else prints "NOT INTEGERS" to STDERR and exits with exit code 1.

Note: Use the below if else conditional statement if needed.

```bash
if condition; then
	...
	...
else
	...
	...
fi
```
