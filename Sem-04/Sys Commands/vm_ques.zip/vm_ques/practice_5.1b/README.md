# Week 5 Problem 5b

Write a Bash script that accepts a name (string) as command line argument to your script <code>script.sh</code> and print "hello <code>input-name</code>" as output, where <code>input-name</code> is the input string.

Example:

If the command line input string is <code>Raghu</code> the output should be
<code>hello Raghu</code>

Write your script in the file <code>script.sh</code>.
