# Week 5 Problem 7

Write a bash script in ` script.sh ` file that takes an integer argument and prints whether the number is prime or not. If the number in the argument  is a prime number, the program must print "Prime" and if not, it must print "Not Prime"
