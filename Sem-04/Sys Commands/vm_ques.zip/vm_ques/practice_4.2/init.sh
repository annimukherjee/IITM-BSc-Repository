dir="/opt/se2001/practice_4.2"
cp $dir/lsinfo.txt .
