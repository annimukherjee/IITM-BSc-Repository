# Week 5 Problem 1a

Write a Bash script that accepts a name (string) as input from <code>stdin</code> and prints "hello <code>input-name</code>" as output, where <code>input-name</code> is the input string.

Example:
If the input string is, <code>Raghu</code> the output should be <code>hello Raghu</code>

Write your script in the file <code>script.sh</code>.
