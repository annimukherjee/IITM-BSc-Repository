# Week 5 Problem 6

Write a bash script in the file ` script.sh ` that accepts an integer argument say ` n ` and prints the below pattern for ` n ` lines.

For example,
In the below sample, the value of `n` is 5
```
*
**
***
****
*****
```

In the below sample, the value of `n` is 4.

```
*
**
***
****
```
