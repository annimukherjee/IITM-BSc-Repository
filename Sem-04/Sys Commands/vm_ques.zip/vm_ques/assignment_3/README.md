# Assignment 3

Define a function ` fibonacci(n) ` in file ` fibonacci.bc `.

The function takes one positional argument which is an integer, say ` n `, and returns ` n `th Fibonacci number in Fibonacci sequence.

Hint : Functions in ` bc `.

## Example :

Fibonacci sequence : 0, 1, 1, 2, 3, 5, 8, 13, .....

If the function is invoked as ` fibonacci(5) `, then the output should be `3`,
as ` 3 ` is at the ` 5 `th position in the Fibonacci sequence. 
