void main(){
	x = 5;
 	printf(x);
	return;
}