text
void main{ //This is main function
	// But it does nothing
	return;
}