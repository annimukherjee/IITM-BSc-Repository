void main()typo{
	x = 5;
 	printf(x);
	return;
}