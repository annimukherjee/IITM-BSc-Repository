dir="/opt/se2001/practice_4.10"
cp $dir/*.cp* .
