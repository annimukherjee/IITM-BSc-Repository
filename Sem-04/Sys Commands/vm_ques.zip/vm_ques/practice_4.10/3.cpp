void somefunction(int x){
	domain=5;
	return domain;
}
