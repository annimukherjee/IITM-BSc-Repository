Welcome to the your zeroth VM Task. This assignment is not graded and provided with a solution file.

**IMPORTANT**: execute `synchro eval` from the assignment directory (for this assignment `~/se2001/assignment_0`) to record your submission for grading.

# Assignment 0 (Not graded)

Write a script `~/se2001/assignment_0/script.sh` that takes a filename as argument and print only the hash value.

# Verification

Once you have written your script you can verify the same using the following command

```
~/se2001/assignment_0/script.sh hello.txt
```

The expected output should be

```
133ee989293f92736301280c6f14c89d521200c17dcdcecca30cd20705332d44
```
