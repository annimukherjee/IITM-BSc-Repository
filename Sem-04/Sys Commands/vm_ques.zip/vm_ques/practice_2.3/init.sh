mkdir {1..12}{A..E}
