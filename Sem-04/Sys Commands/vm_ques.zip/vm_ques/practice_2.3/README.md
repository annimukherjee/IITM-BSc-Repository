# Week 2 Problem 3

A school teaches from first to twelfth standard, each standard has 5 sections named as ` A ` to ` E `. The class room number is represented as standard (as number) followed by the section, for example ` 12E `, ` 3C `, etc..
Each classroom has 40 students. 

There is a directory for every classroom in ` ~/se2001/practice_2.3 `.

Write a Bash command to create a file for each student, name the files from 1 to 40 in every directory.

