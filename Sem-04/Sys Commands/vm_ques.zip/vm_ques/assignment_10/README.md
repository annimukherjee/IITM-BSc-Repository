# Assignment 10

Write a script `~/se2001/assignment_10/script.sh` that takes a filename as argument and print only the MD5 hash value.

The expected output should be

```
916f4c31aaa35d6b867dae9a7f54270d
```
